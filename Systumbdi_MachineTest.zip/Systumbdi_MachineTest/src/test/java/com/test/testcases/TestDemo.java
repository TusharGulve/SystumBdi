package com.test.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.test.pages.Testing;
import com.test.utils.TestInitializer;

public class TestDemo extends TestInitializer{
	
	@Test(description="To check whether board is clickable or not")
	public void demo() throws InterruptedException {
	Testing test = new Testing(driver);
	
	test.login();
	test.clickOnAdministrationMenu();
	test.clickOnSetupMenu();
	test.clickOnPersonalMenu();
	test.selectDept();
	
	String actEle = test.ActboardName.getText(); //Capturing text on which we are clicking
	System.out.println("ActElement :: " +actEle);
	log.info("ActElement :: " +actEle);
	test.clickOnBoard();
	
	String expEle = test.ExpboardName.getAttribute("value"); //Capturing text on edit page
	System.out.println("ExpElement :: " +expEle);
	log.info("ExpElement :: " +expEle);
	
	Assert.assertEquals(actEle, expEle); //If it corrects then only test get passed.
	
	
	}	

}
