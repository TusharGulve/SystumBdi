package com.test.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.test.utils.TestInitializer;
import com.test.utils.TestUtil;

public class Testing extends TestInitializer {

	static WebDriver driver;

	public Testing(WebDriver driver) {

		Testing.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.NAME, using = LoginScreenElements.userName)
	public WebElement username;

	@FindBy(how = How.NAME, using = LoginScreenElements.pass)
	public WebElement password;

	@FindBy(how = How.NAME, using = LoginScreenElements.loginBtn)
	public WebElement loginBtn;

	@FindBy(how = How.NAME, using = LoginScreenElements.loginElement)
	public WebElement loginElement;

	@FindBy(how = How.XPATH, using = LoginScreenElements.AdministrationMenu)
	public WebElement AdministrationMenu;

	@FindBy(how = How.ID, using = LoginScreenElements.SetUp)
	public WebElement SetupMenu;

	@FindBy(how = How.LINK_TEXT, using = LoginScreenElements.PersonalMenu)
	public WebElement personalMenu;
	
	@FindBy(how = How.ID, using = LoginScreenElements.department)
	public WebElement department;
	
	@FindBy(how = How.ID, using = LoginScreenElements.actBoard)
	public WebElement ActboardName;
	
	@FindBy(how = How.ID, using = LoginScreenElements.expBoard)
	public WebElement ExpboardName;

	public void login() {

		username.sendKeys(cache.getProperty("username"));
		password.sendKeys(cache.getProperty("password"));
		loginBtn.submit();
		TestUtil.explicitWait(loginElement);
		log.info("login successfully...");
	}

	public void clickOnAdministrationMenu() throws InterruptedException {

		AdministrationMenu.click();
		Thread.sleep(2000);
		log.info("clicked on Administration menu...");
		
	}
	
	public void clickOnSetupMenu() throws InterruptedException {
		
		try {
		SetupMenu.click();
		log.info("clicked on set up menu for first time...");
		}
		catch(Exception e){
			System.out.println(e);
			driver.get(cache.getProperty("setUpPage_Url"));
			log.info("If timeout comes on set up page then refreshed page again...");
		}
	}

	public void clickOnPersonalMenu() throws InterruptedException {

		TestUtil.switchToFrame(0);
		TestUtil.explicitWait(personalMenu);
		personalMenu.click();
		Thread.sleep(5000);
		log.info("clicked on personal tab");
	}
	
	public void selectDept() throws InterruptedException {
	
		Select sel = new Select(department);
		sel.selectByVisibleText(cache.getProperty("dept"));
		log.info("clicked on z14 dept");
		Thread.sleep(3000);
	}
	
	
	public void clickOnBoard() throws InterruptedException {
		
		Actions act = new Actions(driver);
		act.moveToElement(ActboardName).click().build().perform();
		log.info("clicked on board");
		Thread.sleep(5000);
	}
	
	

}
