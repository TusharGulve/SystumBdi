/**
 * 
 */
package com.test.config;

/**
 * @author Tushar.Gulve
 *
 */
public class ObjectRepository {

	protected static class LoginScreenElements {
		/**
		 * Login page item locator
		 */
		public static final String userName = "txtUserName";
		public static final String pass = "txtUserPass";
		public static final String loginBtn = "submit";
		
		public static final String loginElement = "txtEmail";
		
		public static final String AdministrationMenu = "//div[@id='miTopAdmin']";
		
		public static final String SetUp = "miSetup";
		
		public static final String PersonalMenu = "Personnel";
		
		public static final String department = "departments_select";
		
		public static final String actBoard = "lnameid20265";
		
		public static final String expBoard = "personnel_Last_Name";

	}

}
